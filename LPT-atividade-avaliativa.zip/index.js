class Noticia{
  constructor (titulo, publicação, resumo, texto) {
    this.titulo = titulo;
    this.publicação = publicação;
    this.resumo = resumo;
    this.texto = texto;
  }
mostrarNoticia(){
    return this.titulo + this.publicação + this.resumo + this.texto

  }

}

let noticia = new Noticia('Brasil tem 282 mortes por Covid-19 em 24 horas e chega ao total de 659.294', "29/03/2022", 'São 29.8881.977 casos registrados do novo coronavírus desde o início da pandemia, segundo dados reunidos pelo consórcio de veículos de imprensa. Média móvel de mortes está em 217.', 'O Brasil registrou nesta terça-feira (29) 282 mortes pela Covid-19 nas últimas 24 horas, totalizando 659.294 desde o início da pandemia. Com isso, a média móvel de mortes nos últimos 7 dias é de 217, a mais baixa desde 19 de janeiro de 2021. Em comparação à média de 14 dias atrás, a variação foi de -37%, marcando o 33º dia seguido de tendência de queda nos óbitos decorrentes da doença.')
  console.log(noticia)